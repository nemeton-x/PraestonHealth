import { Component, OnInit } from "@angular/core";
import { DashboardService } from "./dashboard.service";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"]
})
export class DashboardComponent implements OnInit {
  public myQuestionaier = [];
  public surveyResult = [];
  
  
  public responseToSave = [];
  constructor(private dashboardService: DashboardService) {}

  ngOnInit() {
    this.getQuestionaire();
  }

  selectAns(questionId, answer) {
    
    // let answerKeys = [
    //   { answerKey: ["Alcoholic", "Heavy drinker", "Social drinker"] },
    //   { answerKey: ["Beers", "Wines", "Spirits"] },
    //   { answerKey: ["Alcoholic", "Heavy drinker"] }
    // ];
    document.getElementById(questionId + answer).style.border = "2px solid #b7d433"
    document.getElementById(questionId + answer).style.border = "2px solid #b7d433";
    let hasResponse = false;
    this.responseToSave.forEach((resp, index)=>{
      if(resp.questionId == questionId) {
        hasResponse = true;
        this.responseToSave[index].answer = answer;
        return;
      }
    })
    if(!hasResponse) {
      this.responseToSave.push({ questionId: questionId, answer: answer });
    }
  }

  getNextQuestionaire() {
    let responseFinal = this.responseToSave.map(function(item) {
      return item.answer
    });
    this.dashboardService.getNextQuestionaire(responseFinal).subscribe(resp => {
      console.log("resp");
      console.log(resp);
      if (resp) {
        console.log(resp);
        this.surveyResult = resp;
      }
    });
  }

  getQuestionaire() {
    this.dashboardService.getMyQuestions().subscribe(resp => {
      console.log("resp");
      console.log(resp);
      if (resp) {
        console.log(resp);
        this.myQuestionaier = resp;
      }
    });
  }
}
