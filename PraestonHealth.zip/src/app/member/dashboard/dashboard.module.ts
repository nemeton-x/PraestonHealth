import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
// import { QuestionaireComponent } from './questionaire/questionaire.component';
import { DashboardComponent } from "./dashboard.component";
import { routing } from "./dashboard.routing";
import { DashboardService } from "./dashboard.service";

@NgModule({
  imports: [CommonModule, routing],
  declarations: [DashboardComponent],
  providers: [DashboardService]
})
export class DashboardModule {}
